

$('.testimonial-wrap').slick({
  infinite: true,
  dots: true,
  arrows: false,
});



AOS.init({
  duration: 1200,
  once: true
});


